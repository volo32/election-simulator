```
make
./main testfile.txt
make clean
```
